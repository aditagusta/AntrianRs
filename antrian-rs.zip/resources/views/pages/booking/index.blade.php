@extends('layout.index')

<!-- main content -->
<!-- page Title -->
@section('page-title','Data Booking Member')
<!-- Page Content -->
@section('content')
<div class="row mt-3">
    <div class="col-sm-12 col-md-12">
        <table id="table" class="table table-striped table-bordered table-responsive" style="width: 100%">
            <thead>
                <tr>
                    <th style="width: 5%">No</th>
                    <th style="width: 20%">Nama Member</th>
                    <th style="width: 20%">Jenis Pelayanan</th>
                    <th style="width: 20%">Tanggal Booking</th>
                    <th style="width: 5%">Nomor Antrian</th>
                    <th style="width: 5%">Status</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($data as $no => $item)
                    <tr>
                        <td>{{$no+1}}</td>
                        <td>{{$item->nama_member}}</td>
                        <td>{{$item->pelayanan}}</td>
                        <td>{{tanggal_indonesia($item->tanggal_booking)}}</td>
                        <td>{{$item->no_antrian}}</td>
                        <td>{{$item->status}}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
<script>
    $('#table').DataTable()
</script>
@endsection
