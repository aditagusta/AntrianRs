@extends('layout.index')

<!-- main content -->
<!-- page Title -->
@section('page-title','Laporan')
<!-- Page Content -->
@section('content')
<div class="row mt-3">
    <div class="col-sm-12 col-md-12">
        <table id="table" class="table table-striped table-bordered table-responsive" style="width: 100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th style="width: 30%">Nama Member</th>
                    <th style="width: 20%">Jenis Pelayanan</th>
                    <th style="width: 30%">Tanggal Booking</th>
                    <th style="width: 20%">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($data as $no => $item)
                    <tr>
                        <td>{{$no+1}}</td>
                        <td>{{$item->nama_member}}</td>
                        <td>{{$item->pelayanan}}</td>
                        <td>{{tanggal_indonesia($item->tanggal_booking)}}</td>
                        <td>
                            <a href="" class="btn btn-sm btn-primary">Tambah Catatan</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
<script>
    $('#table').DataTable()
</script>
@endsection
