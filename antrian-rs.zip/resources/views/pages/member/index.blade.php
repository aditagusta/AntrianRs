@extends('layout.index')

<!-- main content -->
<!-- page Title -->
@section('page-title','Data Member')
<!-- Page Content -->
@section('content')
<div class="row mt-3">
    <div class="col-sm-12 col-md-12">
        <button class="btn btn-sm btn-primary" onclick="tambah()"><i class="fa fa-plus"></i> Member</button>
        <table id="table" class="table table-striped table-bordered table-responsive">
            <thead>
                <tr>
                    <th>No</th>
                    <th style="width: 10%">Nama Member</th>
                    <th style="width: 10%">Pangkat</th>
                    <th style="width: 10%">Satuan Kerja</th>
                    <th style="width: 20%">Lahir</th>
                    <th style="width: 10%">Alamat</th>
                    <th style="width: 10%">Jenis Kelamin</th>
                    <th style="width: 10%">BPJS</th>
                    <th style="width: 10%">Kelas Pasien</th>
                    <th style="width: 10%">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($data as $no => $item)
                    <tr>
                        <td>{{$no+1}}</td>
                        <td>{{$item->nama_member}}</td>
                        <td>{{$item->pangkat}}</td>
                        <td>{{$item->satuan_kerja}}</td>
                        <td>{{$item->lahir}}</td>
                        <td>{{$item->alamat}}</td>
                        <td>{{$item->jenis_kelamin}}</td>
                        <td>{{$item->bpjs}}</td>
                        <td>{{$item->pasien}}</td>
                        <td>
                            <div class="row">
                                <div class="col-sm-12 col-md-6"><button class="btn btn-sm btn-warning"> Ubah</button></div>
                                <div class="col-sm-12 col-md-6"><button class="btn btn-sm btn-danger"> Hapus</button></div>
                            </div>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="judul"></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="" method="POST">
              @csrf
              <label for="">Username</label>
              <input type="text" class="form-control" id="username" name="username">
              <label for="">Password</label>
              <input type="text" class="form-control" id="password" name="password">
              <label for="">Ulangi Password</label>
              <input type="text" class="form-control" id="password1" name="password1">
              <label for="">Nama Member</label>
              <input type="text" class="form-control" id="nama_member" name="nama_member">
              <label for="">Pangkat</label>
              <input type="text" class="form-control" id="pangkat" name="pangkat">
              <label for="">Satuan Kerja</label>
              <input type="text" class="form-control" id="satuan_kerja" name="satuan_kerja">
              <label for="">Tempat Tanggal Lahir</label>
              <input type="text" class="form-control" id="lahir" name="lahir">
              <label for="">Alamat</label>
              <input type="text" class="form-control" id="alamat" name="alamat">
              <label for="">Jenis Kelamin</label>
              <select name="jenis_kelamin" id="jenis_kelamin" class="form-control">
                  <option value="Perempuan">Perempuan</option>
                  <option value="Pria">Pria</option>
              </select>
              <label for="">BPJS</label>
              <input type="text" class="form-control" id="bpjs" name="bpjs">
              <label for="">Kelas Pasien</label>
              <select name="pasien" id="pasien" class="form-control">
                  <option value="Militer">Militer</option>
                  <option value="PNS">PNS</option>
                  <option value="Keluarga Militer">Keluarga Militer</option>
                  <option value="Keluarga PNS">Keluarga PNS</option>
                  <option value="BPJS">BPJS</option>
                  <option value="Non BPJS">Non BPJS</option>
              </select>
          </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-sm btn-primary" id="simpan">Simpan</button>
            <button class="btn btn-sm btn-warning" id="ubah">Ubah</button>
        </div>
      </div>
    </div>
  </div>
<script>
    function tambah()
    {
        $('#addModal').modal('show')
        document.getElementById('judul').innerHTML = "Form Tambah Data"
        $('#simpan').show()
        $('#ubah').hide()
    }
    $('#table').DataTable()
</script>
@endsection
