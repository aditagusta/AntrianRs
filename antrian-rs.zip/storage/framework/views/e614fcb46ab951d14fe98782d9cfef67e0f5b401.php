<!-- main content -->
<!-- page Title -->
<?php $__env->startSection('page-title','Laporan'); ?>
<!-- Page Content -->
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
    <div class="col-sm-12 col-md-12">
        <table id="table" class="table table-striped table-bordered table-responsive" style="width: 100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th style="width: 30%">Nama Member</th>
                    <th style="width: 20%">Jenis Pelayanan</th>
                    <th style="width: 30%">Tanggal Booking</th>
                    <th style="width: 20%">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no+1); ?></td>
                        <td><?php echo e($item->nama_member); ?></td>
                        <td><?php echo e($item->pelayanan); ?></td>
                        <td><?php echo e(tanggal_indonesia($item->tanggal_booking)); ?></td>
                        <td>
                            <a href="" class="btn btn-sm btn-primary">Tambah Catatan</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<script>
    $('#table').DataTable()
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\antrian-rs\resources\views/pages/laporan/index.blade.php ENDPATH**/ ?>