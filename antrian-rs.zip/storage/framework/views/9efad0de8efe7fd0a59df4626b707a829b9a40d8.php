<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
        <h3>General</h3>
        <ul class="nav side-menu">
            <li><a href="<?php echo e(url('home')); ?>"><i class="fa fa-home"></i> Home</a>
            </li>
            <li><a><i class="fa fa-database"></i> Data Master <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="<?php echo e(route('datamember')); ?>">Data Member</a></li>
                    <li><a href="<?php echo e(route('databooking')); ?>">Data Booking</a></li>
                </ul>
            </li>
            <li><a href="<?php echo e(route('laporan')); ?>"><i class="fa fa-pencil-square-o"></i> Laporan</a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\antrian-rs\resources\views/component/sidebar.blade.php ENDPATH**/ ?>