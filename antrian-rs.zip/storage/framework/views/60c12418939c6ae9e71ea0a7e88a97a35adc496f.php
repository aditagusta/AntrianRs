<!-- main content -->
<!-- page Title -->
<?php $__env->startSection('page-title','Data Booking Member'); ?>
<!-- Page Content -->
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
    <div class="col-sm-12 col-md-12">
        <table id="table" class="table table-striped table-bordered table-responsive" style="width: 100%">
            <thead>
                <tr>
                    <th style="width: 5%">No</th>
                    <th style="width: 20%">Nama Member</th>
                    <th style="width: 20%">Jenis Pelayanan</th>
                    <th style="width: 20%">Tanggal Booking</th>
                    <th style="width: 5%">Nomor Antrian</th>
                    <th style="width: 5%">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no+1); ?></td>
                        <td><?php echo e($item->nama_member); ?></td>
                        <td><?php echo e($item->pelayanan); ?></td>
                        <td><?php echo e(tanggal_indonesia($item->tanggal_booking)); ?></td>
                        <td><?php echo e($item->no_antrian); ?></td>
                        <td><?php echo e($item->status); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<script>
    $('#table').DataTable()
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\antrian-rs\resources\views/pages/booking/index.blade.php ENDPATH**/ ?>