<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class LaporanController extends Controller
{
    public function index()
    {
        $data = DB::table('booking')->join('member','booking.id_member','member.id_member')->get();
        return view('pages.laporan.index',compact('data'));
    }
}
