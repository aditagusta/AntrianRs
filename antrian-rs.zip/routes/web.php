<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('login');
});

Route::post('admin/login','LoginController@login')->name('postlogin');
Route::get('login', 'LoginController@index')->name('login');

Route::group(['middleware' => 'auth:admin'], function () {
    Route::get('logout','LoginController@logout')->name('logout');
    Route::get('home', 'HomeController@index');
    Route::get('data/booking', 'BookingController@index')->name('databooking');
    Route::get('data/member', 'MemberController@index')->name('datamember');
    Route::get('data/laporan', 'LaporanController@index')->name('laporan');
});
